Modern Calculator - Quick Start Guide

No Installation Required!
=======================
1. Download ModernCalculator.exe
2. Double-click to run
That's it! The calculator will start immediately.

Features:
========
- Beautiful modern interface
- Basic arithmetic operations
- Percentage calculations
- Keyboard support
- No installation needed
- Works on Windows

Having Problems?
=============
1. Make sure to extract the .exe from the zip file
2. Try running as administrator
3. Check if your antivirus is blocking it

Need Help?
=========
Contact support at: [your email]
Or visit our website: [your website] 